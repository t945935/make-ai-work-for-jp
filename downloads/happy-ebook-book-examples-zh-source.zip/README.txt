This archive preserves example blocks in the original Chinese. Japanese reader resources are available separately on the repository site.
