Japanese reader-resource samples and source mapping are included in examples-ja/.
