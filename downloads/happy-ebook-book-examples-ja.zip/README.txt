Japanese reader notes and full source index: https://github.com/t945935/make-ai-work-for-jp
The archive contains only the listed examples and provenance manifest.
