wsl.exe --list --verbose
