wsl --install
