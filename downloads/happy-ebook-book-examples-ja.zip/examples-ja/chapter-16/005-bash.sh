date '+%Y-%m-%d %H:%M:%S %Z %z'
